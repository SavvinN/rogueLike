﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rogueLike
{
    internal class Fireball
    {
        private int direction;
        private String mark = "*";
        private ConsoleColor Color = ConsoleColor.Red;

        public Fireball()
        {

        }
    }
}
